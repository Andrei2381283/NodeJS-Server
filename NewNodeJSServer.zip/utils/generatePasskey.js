module.exports = function(){
    return Math.round(Math.random() * 10**10);
}